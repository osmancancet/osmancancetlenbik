---
name: makale-degerlendirme
description: Akademik makale, bildiri, tez ve öğrenci ödevlerini hakem titizliğinde değerlendirir; tek hakem raporu, üç kör hakemli panel raporu + editör sentezi, gönderim öncesi öz-denetim veya rubrikli not önerisi üretir. Kullanıcı bir makale/taslak/müsvedde/PDF paylaşıp "değerlendir", "hakem raporu yaz", "hakemlik yapıyorum", "3 kör hakem", "üç hakemli değerlendirme", "panel", "gönderime hazır mı", "eleştir", "bu tezi oku", "peer review", "review this manuscript", "referee report" dediğinde mutlaka bu skill'i kullan — kullanıcı "skill" kelimesini hiç geçirmese bile. Aynı şekilde makale reddedilme sebeplerini sorduğunda, revizyon isteğine yanıt hazırladığında veya bir çalışmanın yöntem/istatistik sağlamlığını sorguladığında da kullan.
---

# Makale Değerlendirme

Akademik bir metni okuyup, yazarın gerçekten işine yarayan, konumu belli ve
uygulanabilir bulgulardan oluşan bir değerlendirme üretmek için bu akışı izle.

Amaç, metni beğenmek ya da beğenmemek değil: **hangi iddianın hangi kanıtla
desteklendiğini** ve **desteklenmeyen her iddia için ne yapılması gerektiğini**
göstermek.

---

## Adım 0 — Gizlilik kapısı (yalnızca hakem modunda, bir kez)

Dergi hakemliği söz konusuysa, işe başlamadan önce tek seferlik ve kısa bir uyarı
ver, sonra kullanıcının cevabına göre devam et. Bu adımı atlama: ICMJE ve COPE,
hakemlerin değerlendirme aşamasındaki müsveddeyi gizliliği garanti edilmeyen YZ
araçlarına yüklemesini gizlilik ihlali sayar; birçok dergi bunu yazılı olarak
yasaklar, bir kısmı ise editörden izin alınması koşuluyla serbest bırakır.

Uyarının özü şu olmalı (kendi cümlelerinle, iki satırı geçmeden):

> Müsveddeyi buraya yüklemek çoğu derginin hakem gizliliği kuralına takılabilir.
> Derginin YZ politikasını kontrol ettiyseniz veya editörden izin aldıysanız devam
> edelim. Emin değilseniz iki alternatif var: (a) müsveddeyi paylaşmadan, sizin
> aktardığınız bulgular üzerinden rapor dilini birlikte kurarız; (b) yalnızca
> yöntem bölümünü anonimleştirerek tartışırız.

Kullanıcı devam etmek istediğini söylerse konuyu bir daha açma. Kendi makalesini,
tezini veya öğrenci ödevini değerlendiriyorsa bu kapı çalışmaz — o metinler zaten
kendisine aittir.

---

## Adım 1 — Modu belirle

Üç mod var. Bağlamdan çıkarabiliyorsan sorma, doğrudan başla ve hangi modda
çalıştığını raporun başında bir satırla belirt.

| Mod | Ne zaman | Çıktı |
|---|---|---|
| **hakem** | "hakemlik yapıyorum", "dergiden değerlendirme geldi", metin başkasına ait | Editöre + yazara ayrı bölümlü hakem raporu, karar önerisi |
| **panel** | "üç kör hakem", "3 hakem", "panel", "farklı hakemler ne der", derginin süreci taklit edilmek isteniyor | Üç bağımsız kör hakem raporu + editör sentezi |
| **ondenetim** | "kendi makalem", "göndermeden önce", "hazır mı", ortak yazarlık | Gönderim öncesi denetim raporu, öncelik sıralı düzeltme listesi |
| **tez** | tez, dönem projesi, öğrenci ödevi, bitirme çalışması | Rubrikli değerlendirme, gelişime dönük geri bildirim, not önerisi |

**panel**, hakem modunun genişletilmiş hâlidir: aynı çerçeve üç farklı mercekten
bağımsız olarak uygulanır. Kullanıcı kendi makalesi için de panel isteyebilir —
o zaman gizlilik kapısı çalışmaz ama üç mercek aynen uygulanır ve sentez, yazarın
öncelik listesine dönüşür.

İpuçları çelişiyorsa tek soruyla sor, sonra devam et. Mod belirsizliğini bahane
edip değerlendirmeyi geciktirme.

**Modu belirledikten sonra eksik bilgiyi tek bir soruda topla:** hedef dergi/kurum,
alan, yazım dili, derginin hakem formu (varsa), varsa değerlendirme rubriği.
Kullanıcı bilmiyorsa varsayılanları kullan: alanı metinden çıkar, dili metnin diline
eşitle, genel bir hakem formu varsay.

---

## Adım 2 — Künye çıkar

Değerlendirmeye geçmeden önce metnin envanterini çıkar ve raporun başına koy. Bu,
hem senin gözden kaçırmanı engeller hem de kullanıcıya doğru metni okuduğunu
gösterir:

- Başlık, çalışma türü (deneysel / nicel / nitel / karma / derleme / olgu / kuramsal / mühendislik-uygulama)
- Alan ve alt alan
- Bölüm yapısı (IMRaD'a uyuyor mu, eksik bölüm var mı)
- Sayısal envanter: kelime sayısı (yaklaşık), tablo, şekil, denklem, kaynak sayısı
- Kaynakların yıl dağılımı (son 5 yıl oranı) ve kendine atıf oranı gözle çarpıyorsa not et
- Veri: örneklem büyüklüğü, veri kaynağı, veri/kod paylaşımı beyanı var mı
- Beyanlar: etik kurul onayı, aydınlatılmış onam, çıkar çatışması, fon, üretken YZ kullanım beyanı

Bir bilgi metinde yoksa "belirtilmemiş" yaz. **Metinde olmayan bir bilgiyi tahminle
doldurma.** Emin olmadığın her sayının yanına `[DOĞRULA]` koy.

---

## Adım 3 — Metnin tamamını oku, iddia-kanıt eşlemesi yap

Özete ve sonuca bakıp rapor yazma. Sıralı oku ve okurken şunu kaydet:

1. **Öz ve sonuçtaki her iddiayı çıkar.** Her iddia için bulgular bölümünde
   karşılığı olan tabloyu/şekli/istatistiği işaretle.
2. Karşılığı olmayan iddiaları ayrı bir listede tut — bunlar neredeyse her zaman
   raporun en değerli bulguları olur.
3. Yöntemde anlatılan her analizin bulgularda raporlandığını, bulgulardaki her
   sayının yöntemde bir dayanağı olduğunu karşılıklı kontrol et.
4. Tablo ve şekillerdeki sayıların metindeki sayılarla tutarlılığını kontrol et;
   toplamlar, yüzdeler, N değerleri sık sık uyuşmaz.

---

## Adım 4 — Dokuz boyutta değerlendir

Her boyut için ya bir bulgu yaz ya da "sorun görülmedi" de. Boyutları atlama;
atlanan boyut, yazarın en çok ihtiyaç duyduğu yerde sessiz kalmak demektir.

1. **Özgünlük ve katkı.** Çalışma literatüre ne ekliyor? Katkı açıkça
   ifade edilmiş mi, yoksa okuyucunun çıkarması mı bekleniyor? Katkı iddiası
   bulgularla orantılı mı?
2. **Literatür ve konumlandırma.** İlgili güncel çalışmalar var mı, eksik olan
   temel bir kaynak/yaklaşım var mı? Literatür bir liste mi, yoksa boşluğu
   gerçekten kuruyor mu? Alanın son 2-3 yıllık işi temsil edilmiş mi?
3. **Kuramsal çerçeve ve araştırma sorusu.** Soru, hipotez veya amaç açıkça
   yazılmış mı? Kullanılan kuram/model seçimi gerekçelendirilmiş mi? Başlık, öz,
   amaç ve sonuç aynı çalışmayı mı anlatıyor?
4. **Yöntem sağlamlığı.** Araştırma sorusu ile tasarım uyumlu mu? Örnekleme,
   dâhil etme/dışlama, ölçüm araçları, geçerlik-güvenirlik, karşılaştırma
   grubu/temel model, tekrarlanabilirlik için yeterli ayrıntı var mı? Başka biri
   bu metinle çalışmayı tekrarlayabilir mi?
5. **Veri ve analiz.** Analiz yöntemi veri yapısına uygun mu? Varsayımlar
   kontrol edilmiş mi? Etki büyüklüğü/güven aralığı verilmiş mi? Sık rastlanan
   tuzaklar için `references/istatistik-ve-yontem-tuzaklari.md` dosyasını oku.
6. **Bulguların sunumu.** Tablo ve şekiller kendi başına anlaşılıyor mu, gereksiz
   tekrar var mı, metin tabloyu okumaktan mı ibaret? Eksik birim, eksik N, eksik
   ölçek etiketi var mı?
7. **Tartışma ve sonuç tutarlılığı.** Tartışma bulguların ötesine geçiyor mu
   (aşırı genelleme, nedensellik iması, politika önerisi)? Sınırlılıklar gerçek mi
   yoksa süs mü? Sonuç, araştırma sorusuna cevap veriyor mu?
8. **Etik ve yayın bütünlüğü.** Etik onay, onam, çıkar çatışması, fon, yazarlık,
   veri/kod erişimi, YZ beyanı. Ayrıntı ve kırmızı bayraklar için
   `references/etik-ve-yayin-butunlugu.md` dosyasını oku.
9. **Dil, biçim ve kaynakça.** Terim tutarlılığı, başlık-öz uyumu, anahtar
   kelimeler, atıf stili, kaynakça-metin eşleşmesi, derginin yazım kurallarına
   uyum. Dil düzeltmelerini tek tek listeleme: örüntüyü tarif et, 2-3 örnek ver.

Çalışma türüne özgü kontroller için `references/kontrol-listeleri.md` dosyasını
oku ve yalnızca ilgili listeyi uygula. Nitel bir çalışmayı nicel ölçütlerle
yargılamak, raporu değersizleştiren en yaygın hatadır.

---

## Adım 5 — Bulguları şiddetine göre sınıflandır

Her bulguya dört etiketten birini ver. Etiket, yazarın neyi önce yapacağını
belirlediği için işin en kritik kısmı budur.

- **Kritik** — düzeltilmezse sonuçların geçerliliği ortadan kalkar. (Yanlış test,
  veri sızıntısı, etik onay yokluğu, sonucu desteklemeyen veri.)
- **Majör** — sonuç ayakta kalır ama iddia ya da kanıt ciddi biçimde düzeltilmeli.
- **Minör** — netlik, eksik bilgi, sunum. Sonucu etkilemez.
- **Öneri** — zorunlu değil; çalışmayı güçlendirir.

Her bulguyu bu dört parçalı kalıpla yaz. Kalıba uymayan bulgu, yazarın ne
yapacağını bilemediği bulgudur:

> **[Şiddet] · [Konum]** — [Gözlem: metinde ne var/ne yok.]
> [Gerekçe: bu neden sorun.] [İstenen: yazarın atması gereken somut adım.]

Örnek:

> **Kritik · Yöntem, 3.2** — Zaman serisi verisi rastgele bölünerek eğitim/test
> kümesi oluşturulmuş. Bu, geleceğe ait bilginin eğitim kümesine karışmasına yol
> açar ve bildirilen %94 doğruluğu yukarı yönlü yanlı hâle getirir. Bölmeyi
> kronolojik yapın ve sonuçları yeniden raporlayın; performans farkı düşerse
> tartışmayı buna göre güncelleyin.

> **Minör · Tablo 3** — Örneklem sayısı sütun başlıklarında verilmemiş. Okuyucu
> alt grupların ağırlığını göremiyor. Her sütuna n değerini ekleyin.

**Güçlü yanları da yaz.** Her boyutta kusur bulma zorunluluğun yok. Raporun
başında çalışmanın gerçekten iyi yaptığı 2-3 şeyi somut olarak belirt — genel
övgü değil, "hangi kararı neden doğru vermiş" düzeyinde.

---

## Adım 6 — Karar önerisi (hakem modu)

Şiddet dağılımını karara şöyle çevir, ama mekanik davranma; gerekçeyi yaz:

| Durum | Öneri |
|---|---|
| Kritik yok, majör yok | Kabul / yayına uygun |
| Kritik yok, 1-3 majör | Minör revizyon |
| Kritik yok, 4+ majör | Majör revizyon |
| Kritik var ama veriyle giderilebilir | Majör revizyon veya ret-ve-yeniden gönderim |
| Kritik var ve mevcut veriyle giderilemez | Ret |
| Etik ihlal şüphesi, intihal sinyali, yinelenen yayın | Karar önermeden editöre bildir |

Kararı raporun sonuna koy, başına değil: gerekçe okunmadan karar görünmesin.
Nihai kararın editörde olduğunu bir cümleyle hatırlat.

---

## Adım 7 — Panel modu: üç kör hakem

Dergiler müsveddeyi genellikle iki-üç hakeme birlikte gönderir, çünkü tek bir
okuyucu her şeyi görmez. Panel modunun tüm değeri buradadır: **üç hakem farklı
şeyler görmeli ve gerektiğinde çelişmeli.** Üç raporu birbirine benzetirsen mod
işlevsiz kalır.

### Üç mercek

Her hakem yalnızca kendi merceğinden bakar ve diğerinin alanına girmez. H1
istatistik testi tartışmaz, H2 literatür eksiği yazmaz.

| Hakem | Mercek | Yanıtladığı soru |
|---|---|---|
| **H1** | Alan, literatür, kuramsal çerçeve, özgünlük ve katkı (boyut 1-3) | Bu çalışma alana ne katıyor, katkı iddiası orantılı mı? |
| **H2** | Tasarım, örneklem, analiz, tekrarlanabilirlik (boyut 4-5) | Bu veriyle bu yöntemle bu sonuçlara varılabilir mi? |
| **H3** | Sunum, tartışma tutarlılığı, etik beyanlar, dil ve kaynakça (boyut 6-9) | Okuyucu bu metinden doğru sonucu çıkarır mı? |

Mercekleri alana göre uyarla; şablona körü körüne bağlı kalma. Nitel bir
çalışmada H2 "inandırıcılık, refleksivite ve analiz izlenebilirliği" hakemi olur;
sistematik derlemede "arama stratejisi ve yanlılık riski" hakemi olur; mühendislik
uygulamasında H3'e "tekrarlanabilirlik ve kod/veri erişimi" eklenir.

### Sıra

1. H1, H2, H3 raporlarını **sırayla ve bağımsız** yaz. Her rapor kendi başına
   ayakta durur: kısa özet, güçlü yanlar, kendi merceğindeki bulgular, kendi
   karar önerisi. Bir sonraki hakemi yazarken öncekini uyumlaştırmaya çalışma.
2. Sonra editör sentezini yaz.

Üç hakemin aynı kararda buluşması olağandır, ama üçünün de aynı bulguları aynı
şiddetle yazması değildir. Yapay çelişki üretme; gerçek bir ağırlık farkı varsa
onu gizleme de. Bir hakem bir boyutta sorun görmüyorsa bunu açıkça yazsın —
sessizlik, sentezde "kimse bakmadı" gibi görünür.

### Editör sentezi

| Bölüm | İçerik |
|---|---|
| Uzlaşı | En az iki hakemin ortaklaştığı bulgular. Bunlar yazar için birinci sıradadır. |
| Çelişki | Hakemlerin ayrıldığı noktalar. Çelişkiyi çözme, iki gerekçeyi yan yana koy ve editörün neye karar vermesi gerektiğini yaz. |
| Tek hakem, yüksek şiddet | Yalnızca bir hakemin gördüğü ama kritik olan bulgular. Bunları çoğunluk yok diye zayıflatma. |
| Karar dağılımı | Üç hakemin önerisi tabloda. Birleşik öneri, en ağır giderilemez bulgunun gerektirdiği karardır; gerekçesini yaz. |
| Yazara iletilecek liste | Üç raporun tekrarları birleştirilmiş, öncelik sıralı tek liste. Yazar üç ayrı belge okumak zorunda kalmamalı. |

Şablon için `references/rapor-sablonlari.md` dosyasının panel bölümünü kullan.

---

## Kör değerlendirme disiplini

- **Tek kör:** yazar hakemi bilmez. **Çift kör:** ikisi de birbirini bilmez.
  **Üç kör:** editör de yazar kimliğini bilmez. Hangi düzey olursa olsun senin
  kuralın aynıdır: kimlik tahmini yapma, yaptığını yazma.
- Metinde yazar kimliğini sızdıran bir unsur varsa (aşağıdaki liste) onu
  **değerlendirmeye karıştırma**. Yazarın kurumu, ülkesi, kariyer aşaması veya
  ana dili hakkındaki hiçbir çıkarım bulguya dönüşmez.
- Panel modunda üç hakem de aynı körlüğe tabidir; "H1 yazarı tanıyor gibi"
  türü kurgular üretme.
- **Öndenetim modunda ise tersini yap:** kimlik sızdıran unsurları kullanıcıya
  liste hâlinde bildir, çünkü çift kör gönderimde bunlar müsveddenin masa
  başında reddedilmesine yol açar.

Kimlik sızdıran olağan unsurlar: "önceki çalışmamızda (Yazar, 2023)" biçiminde
kendine atıflar, teşekkür ve fon/proje numaraları, etik kurul adı ve karar
numarası, kuruma özgü veri seti veya laboratuvar adları, GitHub/OSF bağlantıları,
dosya üst verisi ve düzeltme geçmişi, dipnottaki iletişim bilgisi, "kendi
üniversitemizde" gibi ifadeler.

---

Mod hangisi olursa olsun rapor şablonunu `references/rapor-sablonlari.md`
dosyasından al ve birebir izle. Şablonlar hem Türkçe hem İngilizce hazır; metnin
dili Türkçeyse Türkçe, uluslararası dergiyse İngilizce yaz (kullanıcı aksini
söylemedikçe).

Tez/öğrenci modunda ağırlıklı rubrik ve 100'lük not eşlemesi için
`references/puanlama-rubrigi.md` dosyasını kullan. Not önerisini her zaman "öneri"
olarak sun; nihai not öğretim elemanının kararıdır.

Rapor uzunluğu: hakem modunda 600-1200 kelime tipik olarak yeterlidir. Daha uzun
rapor daha iyi rapor değildir — bulgu başına bir paragraf, dolgu yok.

Kullanıcı isterse raporu dosya olarak üret (.docx veya .md); istemezse sohbette ver.

---

## Asla yapma

Bu maddeler, raporu kullanışsız hâle getirmekle kalmayıp yazara zarar verebilir:

- **Uydurma.** Okumadığın kaynağı, doğrulamadığın sayıyı, var olmadığı hâlde
  "eksik" dediğin bir literatürü yazma. Emin olmadığın her yere `[DOĞRULA]` koy.
- **Kaynak doğruladığını ima etme.** Ağ erişimin yoksa atıfların gerçekliğini
  kontrol edemezsin; "kaynaklar doğru" veya "bu kaynak mevcut değil" demek yerine
  "atıf bilgileri doğrulanmalı" yaz.
- **İntihal kararı verme.** Benzerlik raporu olmadan intihal suçlaması yapma.
  Yapabileceğin şey şüphe uyandıran örüntüyü (ani stil değişimi, kaynaksız tanım
  blokları) editörün kontrol etmesi için işaret etmektir.
- **Yazar kimliği üzerine yorum.** Yazarın kurumu, ülkesi, cinsiyeti, kariyer
  aşaması, ana dili hakkında çıkarım yapma ve bunları değerlendirmeye karıştırma.
  Kör değerlendirmede yazar tahmini yapma.
- **Belirli kaynakları dayatma.** Kullanıcının veya kendi seçtiğin yazarların
  atıf almasını sağlayacak öneriler yazma; eksik literatürü konu olarak tarif et,
  gerekirse "şu alt alandaki güncel çalışmalar" düzeyinde kal.
- **Metni yeniden yazmak.** Hakem modunda yazarın yerine paragraf yazma. Öndenetim
  modunda yalnızca kullanıcı açıkça isterse yeniden yaz.
- **Nihai kararı senin vermen.** Kabul/ret kararı editörün, not kararı öğretim
  elemanının. Sen gerekçeli öneri üretirsin.
- **Kişiye yönelmek.** Bulgu metne dair olur, yazara dair olmaz. "Yazarlar
  istatistikten anlamıyor" değil, "seçilen test değişkenin ölçüm düzeyine uygun
  değil".

---

## Referans dosyaları

Hepsini birden okuma; ihtiyaç duyduğunu oku.

- `references/rapor-sablonlari.md` — Dört mod için TR/EN rapor şablonları
  (panel şablonu ve editör sentezi dahil). **Rapor yazmaya başlamadan önce
  mutlaka oku.**
- `references/kontrol-listeleri.md` — Çalışma türüne özgü kontrol listeleri
  (nicel, nitel, karma, sistematik derleme, olgu, ölçek geliştirme, makine
  öğrenmesi/mühendislik uygulaması). İlgili bölümü Adım 4'te oku.
- `references/istatistik-ve-yontem-tuzaklari.md` — Sık görülen istatistik ve
  tasarım hataları, nasıl tespit edilir, nasıl yazılır.
- `references/etik-ve-yayin-butunlugu.md` — Etik beyanlar, yazarlık, salamlama,
  yinelenen yayın, YZ beyanı, kırmızı bayraklar.
- `references/puanlama-rubrigi.md` — Tez/öğrenci modu için ağırlıklı rubrik.
