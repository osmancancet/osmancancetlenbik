# Etik ve Yayın Bütünlüğü

Bu boyut, hakem raporunun en çok atlanan ama editör için en değerli kısmıdır.
Kuralları şu kaynaklar belirler: COPE (Committee on Publication Ethics), ICMJE
(tıp dergileri), WAME, STM, Türkiye'de ise YÖK Bilimsel Araştırma ve Yayın Etiği
Yönergesi ile TR Dizin'in etik kuralları.

**Sınır:** Şüpheyi bildirmek hakemin görevi, karar vermek editörün yetkisidir.
Bir ihlali "tespit ettim" diye yazma; gözlemlenen işareti, nerede olduğunu ve
editörün neyi kontrol etmesi gerektiğini yaz.

---

## 1. Zorunlu beyanlar kontrolü

| Beyan | Ne aranır | Yokluğu ne demek |
|---|---|---|
| Etik kurul onayı | Kurul adı, karar tarihi, karar/protokol numarası | İnsan veya hayvan katılımı varsa **kritik**; TR Dizin bunu şart koşar |
| Aydınlatılmış onam | Katılımcılardan alındığına dair açık ifade | İnsan katılımı varsa kritik |
| Çıkar çatışması | "Yoktur" beyanı dahi olsa var mı | Eksikse minör; gizli çıkar varsa ciddi |
| Fon / destek | Proje numarası, destekleyen kurum | Eksikse minör |
| Yazar katkıları | Kimin neyi yaptığı | Çok yazarlı çalışmada beklenir |
| Veri ve kod erişimi | Bağlantı, ambargo veya erişim koşulu | Tekrarlanabilirliği doğrudan etkiler |
| Üretken YZ kullanımı | Hangi araç, hangi amaçla, hangi bölümde | Derginin politikasına göre zorunlu olabilir |

**Etik onay gerekliliği alana göre değişir.** İkincil veri, kamuya açık veri seti,
simülasyon veya tamamen kuramsal çalışmada etik kurul onayı gerekmez; bu durumda
yazarın **neden gerekmediğini** belirtmesi beklenir. Gereksiz yere onay istemek
raporu zayıflatır.

**Retrospektif onay.** Veri toplandıktan sonra alınmış onay tarihleri bir kırmızı
bayraktır; onay tarihinin veri toplama tarihinden sonra olup olmadığını kontrol et.

## 2. Yazarlık

ICMJE ölçütleri: (1) çalışmanın tasarımına veya veri toplama/analiz/yorumuna
anlamlı katkı, (2) metni yazma veya eleştirel gözden geçirme, (3) son sürümü
onaylama, (4) sorumluluk alma. Dördünü birlikte karşılamayan kişi yazar olmaz;
teşekkür bölümüne yazılır.

Kontrol edilecekler:
- Üretken YZ araçları yazar olarak listelenmiş mi? Listelenmişse bu açık bir
  ihlaldir — YZ sorumluluk alamaz.
- Sorumlu yazar ve iletişim bilgisi belirtilmiş mi?
- Yazar sayısı çalışmanın kapsamıyla orantısız görünüyorsa (armağan yazarlık
  şüphesi) bunu ancak katkı beyanı yoksa ve kapsam belirgin biçimde küçükse
  editöre notta belirt. Bu konuda temkinli ol; dışarıdan yanlış değerlendirmesi
  kolay bir husustur.

## 3. Yinelenen yayın ve salamlama

**Salamlama (salami slicing):** Aynı veri setinin bölünerek birden çok yayına
dağıtılması. İşaretler: yöntem bölümünde aynı örneklem ve aynı veri toplama
dönemini tanımlayan, aynı yazar grubuna ait başka yayına atıf; "bu çalışmanın
verisi daha önce X'te kullanılmıştır" beyanının yokluğu.

Rapora yazımı: "Yöntemde tanımlanan örneklem ve veri toplama dönemi, yazarların
[atıf] çalışmasıyla örtüşüyor gibi görünüyor. İki çalışma arasındaki ilişkinin ve
veri örtüşmesinin açıkça beyan edilmesi gerekiyor." — Kararı editöre bırak.

**Yinelenen yayın:** Aynı çalışmanın farklı dergilerde yayımlanması veya bildiri
metninin genişletilmeden makale olarak sunulması. Bildiriden türetilmişse bunun
beyan edilmesi ve genişletmenin ne olduğunun açıklanması beklenir.

## 4. Atıf bütünlüğü

- **Kendine atıf yoğunluğu.** Kaynakçanın önemli bir bölümü yazarların kendi
  çalışmalarıysa ve bunlar metinde işlevsel değilse not et. Sayıyı ver, yorumu
  ölçülü tut.
- **Süs atıf.** Cümleyle ilgisi kurulmayan, yalnızca sayıyı artıran atıflar.
- **Alıntının kaynağını yanlış aktarma.** Atıf verilen kaynağın iddiayı gerçekten
  desteklemediği durumlar; yalnızca okuduğun kaynaklar için söyleyebilirsin.
- **Doğrulanamayan atıflar.** Ağ erişimin yoksa DOI/sayfa bilgilerini kontrol
  edemezsin. "Atıf bilgileri doğrulanmalı" yaz, "bu kaynak yoktur" deme.
  Üretken YZ ile yazılmış metinlerde uydurma atıf sık görülür; şüphe uyandıran
  örüntü (var olmayan dergi adı biçimi, tutarsız cilt/sayı, çok benzer başlıklar)
  varsa editörün kontrol etmesi için işaret et.
- **Atıf kartelleri / zorunlu atıf.** Hakem olarak kendi çalışmalarına atıf
  istemek etik ihlaldir. Bunu asla yapma.

## 5. Üretken yapay zekâ beyanı

Mevcut uzlaşı:
- YZ araçları **yazar olamaz** ve kaynak olarak gösterilemez.
- Yazarların YZ kullanımını **beyan etmesi** beklenir (yöntem veya ayrı bir beyan
  bölümünde: hangi araç, hangi sürüm, hangi amaç).
- Üretilen içeriğin doğruluğundan yazar sorumludur.
- **Hakemler**, değerlendirme aşamasındaki müsveddeyi gizliliği güvence altına
  alınmayan YZ araçlarına yüklememelidir; ICMJE bunu gizlilik ihlali riski olarak
  tanımlar ve dergi izni koşulu getirir, COPE tartışmalarında da hakemlerin
  müsveddeyi YZ araçlarına yüklemesinin gizliliği ve yazarın haklarını ihlal
  edebileceği belirtilir.

Müsveddede YZ kullanımına dair bir işaret varsa (üslup kırılmaları, kaynaksız
tanım blokları, tutarsız terminoloji) bunu suçlamaya dönüştürme: beyan bölümünün
eklenmesini isteyebilirsin.

## 6. Diğer kırmızı bayraklar

- **Görsel bütünlüğü.** Aynı görselin farklı bölümlerde farklı etiketle
  kullanılması, kesme/yapıştırma izleri, eksen etiketi olmayan grafikler,
  ölçek çubuğu olmayan mikroskopi görselleri.
- **Tutarsız sayılar.** Öz, tablo ve metinde farklı değerler; yüzdelerin 100'e
  ulaşmaması; alt grup toplamlarının örnekleme eşit olmaması. Bunları
  hesaplayarak kontrol et — en kolay ve en sağlam bulgu türüdür.
- **Yağmacı dergi ve şüpheli kaynaklar.** Kaynakçada yoğun biçimde bilinmeyen,
  hızlı yayın vadeden dergiler varsa kaynak kalitesini bir bulgu olarak yaz.
- **Veri uydurma/çarpıtma şüphesi.** Standart sapmaların olağandışı düzenliliği,
  gerçekçi olmayan tam sayı örüntüleri. Bu ağır bir iddiadır: yalnızca somut
  gözleme dayandır ve yalnızca editöre notta belirt.
- **İnsan katılımlı güvenlik/sosyal mühendislik çalışmaları.** Aldatma içeren
  tasarımlarda etik kurul onayı, katılımcı bilgilendirme (debriefing) ve veri
  anonimleştirme süreçleri özellikle kontrol edilmeli; toplanan kişisel verinin
  KVKK/GDPR çerçevesinde nasıl korunduğu belirtilmeli.
- **Zarar potansiyeli.** Güvenlik açığı, saldırı yöntemi veya kötüye
  kullanılabilir teknik ayrıntı içeren çalışmalarda sorumlu açıklama süreci ve
  yayınlanan ayrıntı düzeyinin gerekçesi aranmalı.

## 7. Hakemin kendi etiği

- Çıkar çatışması varsa (aynı kurum, ortak yayın, rekabet hâlindeki çalışma)
  hakemliği reddetmek gerekir. Kullanıcı bu durumdaysa hatırlat.
- Müsveddeyi üçüncü kişilerle paylaşma, yayımlanmadan önce içeriğini kullanma.
- Değerlendirme dışı hiçbir yerde müsveddeden alıntı yapma.
- Uzmanlığın dışında kalan bölümler için sınırını editöre bildir. Bu, raporu
  zayıflatmaz — güvenilir kılar.
