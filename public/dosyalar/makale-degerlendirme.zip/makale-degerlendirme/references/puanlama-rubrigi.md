# Puanlama Rubriği (tez / öğrenci modu)

Kullanıcı kendi rubriğini paylaştıysa **onu kullan**, buradakini değil. Paylaşmadıysa
düzeye uygun ağırlıkları uygula ve rubriği raporun içinde göster; öğrenci notun
nereden geldiğini görmeli.

---

## Ağırlıklar

| Boyut | Lisans bitirme | Yüksek lisans tezi | Doktora tezi | Dönem ödevi |
|---|---|---|---|---|
| Problem tanımı ve amaç netliği | 15 | 10 | 10 | 20 |
| Literatür taraması ve konumlandırma | 15 | 20 | 20 | 20 |
| Yöntem uygunluğu ve uygulanışı | 25 | 25 | 25 | 15 |
| Bulguların doğruluğu ve sunumu | 20 | 20 | 20 | 20 |
| Tartışma, yorum ve özgün katkı | 10 | 15 | 20 | 15 |
| Yazım, biçim, kaynak kullanımı | 15 | 10 | 5 | 10 |

Doktorada **özgün katkı** boyutu eşiktir: bu boyut yetersizse toplam puan yüksek
olsa dahi bunu ayrı bir uyarı olarak yaz.

---

## Boyut ölçütleri

Her boyut için dört düzey. Puanı düzey aralığından seç ve **neden o düzey
olduğunu bir cümleyle gerekçelendir.** Gerekçesiz puan geri bildirim değildir.

### Problem tanımı ve amaç netliği
- **Yetersiz (0-40%)** — Amaç yok veya çalışmanın yaptığı şeyle uyuşmuyor.
- **Gelişmeli (40-60%)** — Amaç var ama geniş/muğlak; araştırma sorusu yazılmamış.
- **Yeterli (60-80%)** — Amaç ve soru açık, kapsam makul biçimde sınırlanmış.
- **İyi (80-100%)** — Soru keskin, gerekçesi literatür boşluğuna bağlanmış, kapsam
  bilinçli olarak sınırlanmış.

### Literatür taraması ve konumlandırma
- **Yetersiz** — Birkaç kaynağın özeti; çoğu ikincil veya güncel değil.
- **Gelişmeli** — Kaynaklar var ama liste hâlinde; çalışmayla bağı kurulmamış.
- **Yeterli** — Güncel ve birincil kaynaklar kullanılmış, boşluk tanımlanmış.
- **İyi** — Literatür sınıflandırılmış, çelişkili bulgular karşılaştırılmış,
  çalışmanın yeri açıkça konumlandırılmış.

### Yöntem uygunluğu ve uygulanışı
- **Yetersiz** — Yöntem soruyu cevaplayamaz veya hatalı uygulanmış.
- **Gelişmeli** — Yöntem uygun ama ayrıntı eksik; tekrarlanamaz.
- **Yeterli** — Uygun yöntem, izlenebilir adımlar, temel gerekçeler var.
- **İyi** — Yöntem seçimi alternatiflerle karşılaştırılarak gerekçelendirilmiş;
  geçerlik-güvenirlik veya doğrulama adımları düşünülmüş.

### Bulguların doğruluğu ve sunumu
- **Yetersiz** — Bulgular hatalı, eksik veya yöntemle bağlantısız.
- **Gelişmeli** — Bulgular var ama sunum karışık; tablo/şekil kendi başına
  anlaşılmıyor.
- **Yeterli** — Bulgular doğru ve düzenli sunulmuş.
- **İyi** — Sunum seçimleri (hangi tablo, hangi grafik) bilinçli; metin tabloyu
  tekrarlamak yerine yorumluyor.

### Tartışma, yorum ve özgün katkı
- **Yetersiz** — Tartışma yok veya bulgularla ilgisiz.
- **Gelişmeli** — Bulgular tekrar edilmiş, literatürle karşılaştırma yok.
- **Yeterli** — Bulgular literatürle karşılaştırılmış, sınırlılıklar yazılmış.
- **İyi** — Beklenmedik bulgular tartışılmış, karşı yorumlar ele alınmış, katkı
  abartılmadan ortaya konmuş.

### Yazım, biçim, kaynak kullanımı
- **Yetersiz** — Anlaşılmayı engelleyen dil sorunları; atıf sistemi tutarsız veya
  eksik.
- **Gelişmeli** — Anlaşılır ama dağınık; biçim kurallarına kısmen uyulmuş.
- **Yeterli** — Akıcı, tutarlı atıf, kurallara uygun biçim.
- **İyi** — Akademik ton yerleşmiş, terimler tutarlı, kaynakça kusursuz.

---

## Notu hesaplama

Her boyut için 0-100 arası puan ver, ağırlıkla çarp, topla. Hesabı raporda göster:

```
Problem tanımı        %15 × 72 = 10,8
Literatür             %20 × 65 = 13,0
Yöntem                %25 × 80 = 20,0
Bulgular              %20 × 74 = 14,8
Tartışma/katkı        %15 × 55 =  8,3
Yazım/biçim           %10 × 85 =  8,5
-------------------------------------
Toplam                          75,4
```

Sonucu **öneri** olarak sun: "Rubriğe göre hesaplanan puan 75; nihai not öğretim
elemanının değerlendirmesine tabidir."

---

## Geri bildirim tonu

Öğrenci modunda tek fark ton değil, **öğreticiliktir**. Her kritik bulgunun
yanında öğrencinin ne yapacağını değil, nasıl öğreneceğini göster:

- Zayıf: "Yöntem bölümü yetersiz."
- Orta: "Yöntem bölümüne örneklem seçim ölçütlerini ekleyin."
- İyi: "Yöntem bölümünde örneklem seçim ölçütleri yok. Bir okuyucunun çalışmanızı
  tekrarlayabilmesi için kimin dâhil edildiğini, kimin dışlandığını ve neden
  böyle karar verildiğini yazmanız gerekiyor. Alanınızdaki iki makalenin yöntem
  bölümünü açıp bu üç bilgiyi nasıl verdiklerine bakın, sonra kendi
  paragrafınızı yazın."

Öğrencinin yerine metin yazma. Eksik bölümü tamamlama. Sorunun nerede olduğunu,
neden sorun olduğunu ve hangi yönde çalışması gerektiğini göster; çözümü ona
bırak. Bunun tek istisnası, kullanıcı açıkça örnek metin istediğinde, kısa ve
"örnek" olduğu belirtilmiş bir parça vermektir.

Övgü kısmı zorunludur ve somut olmalı: öğrenci neyi doğru yaptığını bilmezse
sonraki çalışmada da tesadüfen doğru yapar.
