# Rapor Şablonları

İçindekiler:
1. Hakem raporu — Türkçe
2. Hakem raporu — İngilizce
3. Üç kör hakem paneli + editör sentezi
4. Gönderim öncesi öz-denetim raporu
5. Tez / öğrenci değerlendirmesi
6. Hakem yanıtı (revizyon mektubu) — yazar tarafı

Şablonu birebir izle, başlıkları değiştirme. Boş kalan bölümü sil, "uygulanamaz"
yazıp bırakma. Bulgu yoksa "Bu boyutta sorun görülmedi." yaz.

---

## 1. Hakem raporu — Türkçe

```
# Hakem Değerlendirme Raporu

**Müsvedde:** [Başlık]
**Dergi:** [Dergi adı] · **Değerlendirme tarihi:** [Tarih]
**Çalışma türü:** [Tür] · **Değerlendirme modu:** hakem

## 1. Çalışmanın özeti (hakem kalemiyle)
[3-5 cümle. Yazarın özetini kopyalama; çalışmanın ne yaptığını kendi
cümlelerinle anlat. Bu bölüm editöre müsveddeyi okuduğunu ve doğru anladığını
gösterir; yanlış anladığın bir yer varsa yazar bunu buradan fark eder.]

## 2. Genel değerlendirme
[Bir paragraf: çalışmanın alana katkı potansiyeli ve mevcut hâliyle en ciddi
engeli. Karar önerisini burada verme.]

## 3. Güçlü yanlar
- [Somut, gerekçeli. "İyi yazılmış" değil; "X yönteminin seçimi Y kısıtı
  nedeniyle yerinde ve gerekçesi 2.3'te açıkça kurulmuş".]

## 4. Kritik bulgular
[Yoksa bu bölümü tamamen sil.]
**Kritik · [Konum]** — [Gözlem.] [Gerekçe.] [İstenen düzeltme.]

## 5. Majör bulgular
**Majör · [Konum]** — [Gözlem.] [Gerekçe.] [İstenen düzeltme.]

## 6. Minör bulgular
**Minör · [Konum]** — [Gözlem.] [İstenen düzeltme.]

## 7. Öneriler (zorunlu değil)
- [Çalışmayı güçlendirecek, ancak bu turda şart olmayan öneriler.]

## 8. Etik ve beyan kontrolü
| Beyan | Durum |
|---|---|
| Etik kurul onayı | [var / yok / uygulanamaz / belirtilmemiş] |
| Aydınlatılmış onam | |
| Çıkar çatışması | |
| Fon/destek | |
| Veri ve kod erişimi | |
| Üretken YZ kullanım beyanı | |

## 9. Karar önerisi
**[Kabul / Minör revizyon / Majör revizyon / Ret ve yeniden gönderim / Ret]**

[Gerekçe: 2-4 cümle, en ağır bulgulara atıfla.]

Nihai karar editöre aittir.

---
### Editöre özel notlar (yazara iletilmez)
[Yalnızca editörün bilmesi gereken hususlar: etik şüphe, olası yinelenen yayın,
hakemin uzmanlık sınırı. Hakemin kendi uzmanlığının dışında kalan bölümleri
burada açıkça belirt — bu, raporun güvenilirliğini artırır.]
```

---

## 2. Hakem raporu — İngilizce

```
# Reviewer Report

**Manuscript:** [Title]
**Journal:** [Journal] · **Date:** [Date]
**Study type:** [Type]

## 1. Summary of the manuscript
[3-5 sentences in the reviewer's own words.]

## 2. General assessment
[One paragraph: potential contribution and the most serious obstacle in the
current form. No recommendation yet.]

## 3. Strengths
- [Specific and justified.]

## 4. Critical issues
**Critical · [Location]** — [Observation.] [Why it matters.] [Requested action.]

## 5. Major issues
**Major · [Location]** — [Observation.] [Why it matters.] [Requested action.]

## 6. Minor issues
**Minor · [Location]** — [Observation.] [Requested action.]

## 7. Optional suggestions
- [...]

## 8. Declarations checklist
| Declaration | Status |
|---|---|
| Ethics approval | |
| Informed consent | |
| Conflict of interest | |
| Funding | |
| Data and code availability | |
| Generative AI disclosure | |

## 9. Recommendation
**[Accept / Minor revision / Major revision / Reject and resubmit / Reject]**

[Justification, 2-4 sentences.]

The final decision rests with the editor.

---
### Confidential comments to the editor
[...]
```

---

## 3. Üç kör hakem paneli + editör sentezi (mod: panel)

Üç raporu tek belgede, bu sırayla yaz. Her hakem bölümü kendi başına okunabilir
olmalı; kısaltma amacıyla "H1'de belirtildiği gibi" türü çapraz atıf yapma —
gerçek hakemler birbirinin raporunu görmez.

```
# Panel Değerlendirmesi — [Başlık]

**Müsvedde:** [Başlık] · **Dergi:** [Dergi] · **Tarih:** [Tarih]
**Körlük düzeyi:** [tek / çift / üç kör]
**Panel:** H1 alan ve katkı · H2 yöntem ve analiz · H3 sunum, etik ve bütünlük

---

## Hakem 1 — Alan, literatür ve katkı

**Özet (H1 kalemiyle):** [2-3 cümle.]
**Güçlü yanlar:** [1-2 madde.]

**[Şiddet] · [Konum]** — [Gözlem.] [Gerekçe.] [İstenen düzeltme.]
...

**H1 karar önerisi:** [Karar] — [tek cümle gerekçe.]
**H1 uzmanlık sınırı:** [H1'in değerlendirmediği bölümler.]

---

## Hakem 2 — Tasarım, analiz ve tekrarlanabilirlik

[Aynı yapı.]

**H2 karar önerisi:** [Karar] — [gerekçe.]
**H2 uzmanlık sınırı:** [...]

---

## Hakem 3 — Sunum, tartışma, etik ve kaynakça

[Aynı yapı.]

**H3 karar önerisi:** [Karar] — [gerekçe.]
**H3 uzmanlık sınırı:** [...]

---

# Editör Sentezi

## Karar dağılımı
| Hakem | Öneri | En ağır bulgusu |
|---|---|---|
| H1 | | |
| H2 | | |
| H3 | | |

**Birleşik öneri:** [Karar]
[Gerekçe: en ağır giderilemez bulguya atıfla 2-3 cümle.]

## Uzlaşı (en az iki hakem)
- [Bulgu.] (H1, H2)

## Çelişki
- **[Konu]** — H2 [görüş ve gerekçe]; H3 [karşıt görüş ve gerekçe].
  Editörün karar vermesi gereken nokta: [ne.]
  [Çelişkiyi kendin çözme; hangi ek bilginin çözeceğini yaz.]

## Tek hakemde çıkan, yüksek şiddetli bulgular
- **[Şiddet] · [Konum]** — [Bulgu.] (yalnızca H2)
  [Tek hakemde çıkması bulguyu zayıflatmaz; gerekçesi güçlüyse öyle yaz.]

## Yazara iletilecek birleşik liste (öncelik sırasıyla)
1. **[Konum]** — [İstenen düzeltme.] [Hangi hakemlerden geldiği.]
2. ...

## Panel kapsamındaki boşluklar
[Üç merceğin de bakmadığı ve ek uzmanlık gerektiren hususlar. Örn. "Kullanılan
ölçeğin dil geçerliği alan uzmanı tarafından değerlendirilmeli."]
```

### Panel modunun kalite ölçütü

Raporu bitirdikten sonra şuna bak: üç hakem bölümü birbirinin yeniden yazımı mı
oldu? Olduysa mercekler çalışmamış demektir. Her hakemin bulguları ağırlıklı
olarak kendi boyut kümesinden gelmeli; yalnızca kritik şiddetli bulgularda bir
hakem kendi merceğinin dışına çıkabilir — o zaman da bunu açıkça belirtsin
("H2 notu: bu bulgu H3'ün alanına girer ancak sonuçların geçerliliğini
etkilediği için burada belirtiyorum").

Üçünün de "kabul" dediği bir müsveddede sentezi kısaltabilirsin, ama karar
dağılımı tablosunu ve panel boşlukları bölümünü yine yaz.

---

## 4. Gönderim öncesi öz-denetim raporu (mod: ondenetim)

Bu modda kullanıcı yazarın kendisidir. Amaç "kabul edilir mi" tahmini değil,
**gönderimden önce kapatılacak açıkların öncelik sıralı listesi**. Hakemin
soracağı soruları önceden sor.

```
# Gönderim Öncesi Denetim — [Başlık]

**Hedef dergi:** [Dergi] · **Mod:** öndenetim

## Kısa hüküm
[2-3 cümle: mevcut hâliyle en olası hakem tepkisi ne olur. Örn. "Mevcut hâliyle
en olası sonuç majör revizyon; en kırılgan nokta tek veri setiyle genelleme
iddiası."]

## Gönderim öncesi kapatılması gerekenler (öncelik sırasıyla)
1. **[Konum]** — [Ne yapılacak.] [Neden: hakem buna şunu sorar.]
2. ...

## Hakemin soracağı sorular
[Yazarın hazırlıklı olması gereken 4-6 soru. Her birinin altına tek satır:
cevap şu anda metinde var mı, yoksa nereye eklenmeli.]

## Dergi uyum kontrolü
| Ölçüt | Derginin istediği | Müsveddede |
|---|---|---|
| Kelime sınırı | | |
| Öz uzunluğu / yapısı | | |
| Atıf stili | | |
| Şekil/tablo sayısı ve formatı | | |
| Zorunlu beyanlar | | |
| Kapsam uyumu (aims & scope) | | |

[Derginin kuralları elinde yoksa bu tabloyu boş bırakma; sütuna `[DOĞRULA]`
yazıp kullanıcıya derginin yazar rehberini paylaşmasını öner.]

## Sonraki tur için notlar
- [Bu gönderimi geciktirmemesi gereken ama sonraki çalışmada düşünülmesi
  gereken hususlar.]
```

---

## 5. Tez / öğrenci değerlendirmesi (mod: tez)

Bu modda ton değişir: öğrenci öğrenme sürecindedir. Bulgular aynı titizlikte
kalır ama her kritik bulgunun yanında **nasıl düzeltileceği öğretilir**.

```
# Değerlendirme — [Çalışma adı]

**Öğrenci/çalışma:** [—] · **Düzey:** [lisans bitirme / yüksek lisans / doktora / dönem ödevi]
**Rubrik:** [kullanılan rubrik]

## Ne iyi yapılmış
- [2-4 madde, somut.]

## Önce bunları düzelt
1. **[Konum]** — [Sorun.] [Nasıl düzeltilir: yöntem düzeyinde yol gösterici,
   cevabı yazmadan.] [Bakılabilecek kaynak türü.]

## Boyut bazlı değerlendirme
| Boyut | Ağırlık | Puan | Gerekçe |
|---|---|---|---|
[puanlama-rubrigi.md dosyasındaki ağırlıkları kullan]

## Not önerisi
**[X]/100 — [harf notu karşılığı varsa]**
Bu bir öneridir; nihai not öğretim elemanının kararıdır.

## Savunmada sorulabilecek sorular
- [3-5 soru.]
```

---

## 6. Hakem yanıtı (revizyon mektubu) — yazar tarafı

Kullanıcı eline hakem raporu geçmiş bir yazar ise ve yanıt hazırlıyorsa bu
şablonu kullan. Kural: **her hakem maddesine ayrı ayrı, sırayla ve aynı
numarayla cevap ver**; hiçbir maddeyi cevapsız bırakma.

```
# Revizyona Yanıt — [Başlık]

Sayın Editör,

[Bir paragraf: revizyon için teşekkür, yapılan değişikliklerin özeti, metinde
değişikliklerin nasıl işaretlendiği.]

## Hakem 1

**H1.1 —** [Hakemin maddesi, kısaltılarak alıntılanır.]
**Yanıt:** [Kabul mü, kısmen mi, gerekçeli itiraz mı.] [Yapılan değişiklik.]
**Değişiklik yeri:** [Bölüm, sayfa, satır. Yeni metni buraya kısa alıntıyla koy.]

...
```

İtiraz edilecek maddelerde ton kuralı: hakemin yorumunu geçersiz ilan etme,
dayanağı göster. "Hakemin belirttiği yöntem, X koşulu nedeniyle bu veri
yapısında uygulanamıyor; gerekçesi 3.2'ye eklendi." Cevabı olmayan maddeye
"düzeltilmiştir" yazıp geçme — hangi cümlenin nasıl değiştiğini göster.
