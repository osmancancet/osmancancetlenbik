# Çalışma Türüne Özgü Kontrol Listeleri

Yalnızca müsveddenin türüne uyan bölümü oku ve uygula. Bir çalışmayı kendi
türünün ölçütleriyle değerlendir: nitel bir çalışmada örneklem büyüklüğü
küçüklüğünü kusur saymak ya da kuramsal bir makalede veri istemek raporu
değersizleştirir.

İçindekiler:
1. Nicel / deneysel
2. Anket ve ölçek temelli
3. Ölçek geliştirme ve uyarlama
4. Nitel
5. Karma yöntem
6. Sistematik derleme ve meta-analiz
7. Anlatısal derleme
8. Olgu sunumu / vaka çalışması
9. Makine öğrenmesi ve yapay zekâ uygulamaları
10. Mühendislik tasarımı, sistem ve simülasyon
11. Kuramsal / kavramsal
12. Tüm türler için ortak son kontrol

Alanın kendi raporlama kılavuzu varsa ona atıf yap: CONSORT (randomize
denemeler), STROBE (gözlemsel), PRISMA (sistematik derleme), COREQ/SRQR (nitel),
CARE (olgu sunumu), TRIPOD+AI (klinik tahmin modelleri), STARD (tanı doğruluğu).
Kılavuz adını yalnızca alan gerçekten örtüşüyorsa kullan.

---

## 1. Nicel / deneysel

- Araştırma sorusu, hipotez ve analiz üçlüsü birbirine karşılık geliyor mu?
- Tasarım soruyu cevaplayabiliyor mu (kesitsel veriyle nedensellik iddiası var mı)?
- Örneklem: nasıl seçildi, temsil gücü, dâhil etme/dışlama ölçütleri, kayıp veri
  oranı ve nasıl ele alındığı.
- Güç analizi yapılmış mı; yapılmadıysa örneklem büyüklüğünün gerekçesi var mı?
- Değişkenlerin ölçüm düzeyi ile seçilen test uyumlu mu?
- Varsayım kontrolleri (normallik, varyans homojenliği, çoklu bağlantı) raporlanmış mı?
- Etki büyüklüğü ve güven aralığı var mı, yoksa yalnızca p değeri mi?
- Karıştırıcı değişkenler (confounder) tanımlanıp kontrol edilmiş mi?
- Randomizasyon ve körleme (varsa) nasıl yapıldı?
- Sonuçlar hipotezi desteklemiyorsa bu açıkça yazılmış mı, yoksa hipotez sonradan
  mı uyarlanmış görünüyor?

## 2. Anket ve ölçek temelli

- Kullanılan ölçeğin kaynağı, izin durumu, dil geçerliği.
- Cronbach alfa / bileşik güvenirlik bu örneklem için hesaplanmış mı, yoksa
  yalnızca özgün çalışmadan mı aktarılmış?
- Veri toplama biçimi (yüz yüze, çevrimiçi), yanıt oranı, yanıtsızlık yanlılığı.
- Kolayda örnekleme kullanıldıysa bunun sınırlılığı yazılmış mı?
- Ortak yöntem yanlılığı (common method bias) tartışılmış mı?
- Likert verisinin analiz düzeyi (sıralı mı aralık mı varsayıldı) gerekçelendirilmiş mi?

## 3. Ölçek geliştirme ve uyarlama

- Madde havuzu nasıl oluşturuldu, kapsam geçerliği için uzman görüşü alındı mı?
- AFA ve DFA ayrı örneklemlerde mi yapıldı?
- Faktör sayısı kararının ölçütü (özdeğer, paralel analiz, scree) belirtilmiş mi?
- Uyum iyiliği indeksleri ve eşik değerleri, madde yükleri, çapraz yükler.
- Ayırt edici ve yakınsak geçerlik kanıtları.
- Test-tekrar test güvenirliği, zaman aralığı.
- Uyarlama çalışmalarında çeviri-geri çeviri süreci ve kültürel eşdeğerlik.

## 4. Nitel

- Yöntemsel gelenek adıyla konmuş mu (olgubilim, gömülü teori, durum çalışması,
  söylem analizi) ve uygulanan adımlar bu geleneğe uyuyor mu?
- Katılımcı seçimi ölçütü ve doyum (saturation) gerekçesi.
- Veri toplama araçları: görüşme formunun nasıl geliştirildiği, pilot uygulama.
- Analiz süreci izlenebilir mi: kodlama nasıl yapıldı, kod-tema geçişi nasıl kuruldu?
- İnandırıcılık stratejileri: katılımcı teyidi, akran incelemesi, kodlayıcılar
  arası uyum, derin betimleme, denetim izi (audit trail).
- Araştırmacının konumu (refleksivite) belirtilmiş mi?
- Alıntılar bulguyu destekliyor mu, yoksa süs mü? Alıntı-yorum dengesi.
- Etik: onam, gizlilik, kimliğin gizlenmesi, hassas grup varsa ek koruma.
- **Yapma:** genelleme istemek, örneklem büyütmeyi şart koşmak, nicel geçerlik
  dilini zorlamak.

## 5. Karma yöntem

- Karma desen adıyla konmuş mu (yakınsayan, açıklayıcı sıralı, keşfedici sıralı)?
- Nitel ve nicel bileşenlerin ağırlığı ve sırası gerekçelendirilmiş mi?
- Bütünleştirme (integration) gerçekten yapılmış mı, yoksa iki ayrı çalışma yan
  yana mı duruyor? Bu türün en sık kusuru budur.
- Uyuşmazlık durumunda (nitel ve nicel bulgular çelişiyorsa) nasıl yorumlandı?

## 6. Sistematik derleme ve meta-analiz

- Protokol önceden kayıtlanmış mı (PROSPERO vb.)?
- Arama stratejisi tam olarak verilmiş mi: veri tabanları, tarih aralığı, arama
  dizgeleri, dil kısıtı? Başkası tekrarlayabilir mi?
- Akış diyagramı ve her aşamada dışlanan çalışma sayısı/nedeni.
- Dâhil etme ölçütleri önceden tanımlı mı?
- Kalite/yanlılık riski değerlendirmesi hangi araçla, kaç bağımsız
  değerlendiriciyle yapıldı; uyuşmazlık nasıl çözüldü?
- Heterojenlik ölçümü ve etki modeli seçimi (sabit/rastgele) gerekçesi.
- Yayın yanlılığı kontrolü (huni grafiği, Egger).
- Alt grup ve duyarlılık analizleri.

## 7. Anlatısal derleme

- Kapsam ve seçim ölçütü belirtilmiş mi, yoksa keyfi bir seçki mi?
- Derleme yalnızca özetler dizisi mi, yoksa sentez ve sınıflandırma üretiyor mu?
  Katkı iddiası bu sentezde olmalı.
- Güncellik: alanın son dönemdeki işi kapsanmış mı?
- Kendine atıf yoğunluğu.
- Çelişkili bulgular karşı karşıya getirilmiş mi?
- Gelecek araştırma önerileri genel geçer mi, yoksa derlemenin bulgusundan mı
  çıkıyor?

## 8. Olgu sunumu / vaka çalışması

- Olgunun neden anlatılmaya değer olduğu (yenilik, öğreticilik) açık mı?
- Kronolojik anlatı tam mı; eksik zaman dilimi var mı?
- Kimliği açık edebilecek ayrıntılar temizlenmiş mi?
- Hasta/katılımcı onamı beyan edilmiş mi?
- Tek olgudan genelleme iddiası var mı?
- İlgili literatürle karşılaştırma yapılmış mı?

## 9. Makine öğrenmesi ve yapay zekâ uygulamaları

- Veri: kaynak, sürüm, boyut, sınıf dağılımı, etiketleme süreci ve etiket
  güvenirliği (kodlayıcılar arası uyum).
- Bölme: eğitim/doğrulama/test ayrımı açık mı? Zaman serisinde kronolojik bölme
  kullanılmış mı? Test kümesine ön işleme veya öznitelik seçimi sızmış mı?
- **Veri sızıntısı** için özel kontrol: ölçekleme/normalizasyon tüm veri üzerinde
  mi yapıldı, aynı denek/kaynak hem eğitimde hem testte var mı, hedefle
  ilişkili gelecek bilgisi öznitelik olarak girmiş mi?
- Temel model (baseline) var mı? Basit bir yöntemle (lojistik regresyon, ağırlıklı
  tahmin, "önceki değeri tahmin et") karşılaştırma yapılmadıysa bu majör bulgudur.
- Metrikler sorun tipine uygun mu? Dengesiz veride yalnızca doğruluk verilmişse
  precision/recall/F1, PR-AUC, MCC istenmeli; regresyonda MAE/RMSE/MAPE.
- Belirsizlik: tek koşu mu, çoklu tohum (seed) ortalaması ve standart sapma var mı?
- Hiperparametre arama uzayı ve seçim yöntemi; seçim test kümesinde mi yapıldı?
- Çapraz doğrulama kurgusu (katman sayısı, gruplu/zamansal CV).
- Ablasyon: iddia edilen bileşenin katkısı ayrı ayrı gösterilmiş mi?
- Tekrarlanabilirlik: kod ve veri erişimi, kütüphane sürümleri, rastgelelik
  tohumu, donanım ve eğitim süresi.
- Açıklanabilirlik iddiası varsa (SHAP, LIME, dikkat haritaları) yöntemin sınırları
  tartışılmış mı; öznitelik önemi nedensellik gibi sunulmuş mu?
- Karşılaştırılan literatür sonuçları aynı veri ve aynı bölme üzerinde mi?
  Farklı kurgulardaki sayıları yan yana koymak yanıltıcıdır.
- Model kartı / etik değerlendirme: yanlılık, kötüye kullanım, gizlilik.
- Büyük dil modeli kullanıldıysa: model adı ve sürümü, istem (prompt) metinleri,
  sıcaklık ve diğer üretim parametreleri, kaç tekrar, değerlendirmenin nasıl
  yapıldığı. Sürüm belirtilmemişse çalışma tekrarlanamaz — majör bulgu.

## 10. Mühendislik tasarımı, sistem ve simülasyon

- Problem tanımı ve tasarım gereksinimleri ölçülebilir mi?
- Tasarım alternatifleri karşılaştırılmış mı, seçim ölçütü nedir?
- Simülasyon: model varsayımları, parametre kaynakları, doğrulama (verification)
  ve geçerleme (validation) ayrı ayrı yapılmış mı?
- Duyarlılık analizi var mı?
- Deneysel doğrulama varsa ölçüm belirsizliği ve tekrar sayısı.
- Maliyet, güvenlik, standartlara uyum (ilgiliyse).
- Güvenlik çalışmalarında: test ortamı, izin/etik durumu, sorumlu açıklama
  (responsible disclosure) süreci, saldırı senaryosunun gerçekçiliği.

## 11. Kuramsal / kavramsal

- Argümanın öncülleri açık mı, çıkarım adımları izlenebilir mi?
- Tanımlar tutarlı mı, aynı terim farklı yerlerde farklı anlamda mı kullanılıyor?
- Karşıt görüşler dürüstçe temsil edilip yanıtlanmış mı?
- Önerilen çerçevenin sınanabilirliği veya uygulanabilirliği gösterilmiş mi?
- Veri olmaması kusur değildir; kanıt yerine sezgiye dayanan atlamalar kusurdur.

---

## 12. Tüm türler için ortak son kontrol

Raporu kapatmadan önce şunlara bak:

- Başlık çalışmanın yaptığı şeyi mi anlatıyor, yoksa yapmayı umduğu şeyi mi?
- Öz, bulgu içeriyor mu (sayı veya yön) yoksa yalnızca niyet beyanı mı?
- Anahtar kelimeler indekslenebilir mi, başlıkla gereksiz tekrar ediyor mu?
- Metindeki her tablo ve şekle atıf var mı, her tablo gerçekten gerekli mi?
- Kaynakçadaki her kaynak metinde, metindeki her atıf kaynakçada var mı?
- Kısaltmalar ilk geçtikleri yerde açılmış mı, sonra tutarlı kullanılmış mı?
- Sınırlılıklar bölümü gerçek sınırlılıkları mı yazıyor?
- Sonuç, özdeki iddiayla aynı şeyi mi söylüyor?
- Bulgu sayın 15'i aştıysa: en önemli 8-10'una indir, kalanını "minör" başlığı
  altında tek listede topla. Yazarın uygulayamayacağı uzunlukta rapor yardım
  etmez.
