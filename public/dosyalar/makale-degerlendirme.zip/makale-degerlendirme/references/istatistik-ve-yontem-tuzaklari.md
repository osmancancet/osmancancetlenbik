# İstatistik ve Yöntem Tuzakları

Her madde şu üçlüyle yazılmıştır: **nasıl anlaşılır → neden sorun → rapora nasıl
yazılır.** Bir tuzağı ancak metinde işareti varsa bulgu olarak yaz; "bu hata
yapılmış olabilir" diye varsayım üzerine bulgu kurma. İşaret belirsizse bulguyu
soru biçiminde yaz — bu, hakem raporunda meşru ve yazar için en kullanışlı biçimdir.

---

## A. Çıkarım ve test seçimi

**Ölçüm düzeyi ile test uyuşmazlığı.** Sıralı veya kategorik veriye aralık ölçek
testleri uygulanması. → Test varsayımı ihlal edilir, p değeri yorumlanamaz. →
"Bağımlı değişken üç kategorili sıralı bir ölçek; uygulanan bağımsız örneklem
t-testi bu ölçüm düzeyine uygun değil. Sıralı veriye uygun bir test ile yeniden
analiz edip sonucu güncelleyin."

**Çoklu karşılaştırma düzeltmesi yokluğu.** Onlarca test, hiç düzeltme yok, birkaç
anlamlı sonuç vurgulanmış. → Yanlış pozitif oranı hedeflenen düzeyin çok üstüne
çıkar. → "Bölüm 4'te [n] ayrı test raporlanmış; çoklu karşılaştırma düzeltmesi
belirtilmemiş. Düzeltme uygulayın veya keşfedici doğa açıkça beyan edilsin ve
sonuçlar buna göre çerçevelensin."

**Yalnızca p değeri.** Etki büyüklüğü ve güven aralığı yok. → Anlamlılık, etkinin
büyüklüğü hakkında bilgi vermez; büyük örneklemde önemsiz farklar anlamlı çıkar. →
"Etki büyüklüğü ve %95 güven aralığı eklenmeli; bulgunun pratik önemi bu olmadan
değerlendirilemez."

**p = 0,05 eşiği etrafında anlatı.** "Anlamlılığa yaklaştı", "marjinal anlamlı". →
İkili eşik keyfîdir; sınır anlatısı sonucu olduğundan güçlü gösterir. → Sınır
değerlerin düz raporlanmasını isteyin.

**Anlamsız sonucun yokluk kanıtı sayılması.** "Fark bulunmadı, dolayısıyla etki
yok." → Kanıt yokluğu, yokluk kanıtı değildir; düşük güç aynı sonucu verir. →
"Anlamlı fark bulunmaması etkisizlik kanıtı olarak sunulmuş. Güç analizi veya
eşdeğerlik testi olmadan bu çıkarım yapılamaz."

**Gruplar arası karşılaştırma yerine grup içi anlamlılık.** İki grubun her birinde
ayrı ayrı anlamlılık test edilip "gruplar farklı" denmesi. → Doğru test etkileşim
testidir. → Etkileşim teriminin doğrudan test edilmesini isteyin.

## B. Tasarım ve nedensellik

**Kesitsel veriyle nedensellik.** "X, Y'yi artırır/azaltır", "etkisi" dili. →
Zamansal öncelik ve karıştırıcı kontrolü yoksa nedensellik kurulamaz. → "Tasarım
kesitsel olduğundan nedensel dil kullanılamaz. Özdeki ve 5. bölümdeki 'etkiler'
ifadeleri ilişkisel dile çevrilmeli."

**Karıştırıcı değişken ihmali.** Alanın bilinen belirleyicileri modele girmemiş. →
Tahmin yanlı olur. → Hangi değişkenin neden eklenmesi gerektiğini gerekçeli yazın.

**Seçim yanlılığı.** Örneklem kendi kendini seçmiş (gönüllü, çevrimiçi duyuru),
sonuçlar evrene genelleniyor. → "Kolayda/gönüllü örneklemle toplanan veri üzerinden
[evren] hakkında genelleme yapılmış. Genelleme iddiası daraltılmalı ve sınırlılık
olarak yazılmalı."

**Hayatta kalma yanlılığı ve kayıp veri.** Kayıp oranı yüksek veya hiç
raporlanmamış; silme yöntemi belirsiz. → "Kayıp veri oranı ve ele alınma biçimi
(liste bazlı silme mi, çoklu atama mı) belirtilmemiş; bu bilgi olmadan örneklemin
temsil gücü değerlendirilemez."

**HARKing (sonucu gördükten sonra hipotez kurma).** Hipotezler tam olarak verinin
gösterdiği örüntüye oturuyor, ön kayıt yok, "keşfedici" ifadesi geçmiyor. → Bunu
suçlama olarak yazma; "hipotezlerin önceden mi kurulduğu belirsiz, ön kayıt veya
keşfedici beyan eklenmeli" biçiminde yaz.

**Alt grup avı.** Ana etki anlamsız, çok sayıda alt grupta bir tanesi anlamlı ve
vurgulanmış. → "Alt grup analizleri keşfedici olarak işaretlenmeli ve ana etkinin
anlamsız olduğu özde de görünmeli."

## C. Model kurma ve tahmin

**Aşırı uyum (overfitting) ve serbestlik derecesi.** Örneklem küçük, model
karmaşık, çok sayıda öngörücü. → Kaba bir kural olarak lojistik regresyonda her
öngörücü için yeterli olay sayısı sorulmalı. → "Olay sayısı ([n]) öngörücü
sayısına ([k]) göre düşük; modelin dış geçerliği sınırlı. Değişken azaltma veya
düzenlileştirme (regularization) düşünülmeli."

**Adımsal (stepwise) değişken seçimi.** Otomatik seçimle kurulan model tek
doğruymuş gibi sunulmuş. → Seçim süreci p değerlerini ve katsayıları bozar. →
Kuram temelli model belirtimini veya düzenlileştirmeyi öneri olarak yazın.

**Sürekli değişkenin keyfî kategorileştirilmesi.** Medyandan bölme, keyfî eşik. →
Bilgi kaybı ve eşik seçimine bağlı sonuç. → Gerekçe ve duyarlılık analizi isteyin.

**Çoklu bağlantı (multicollinearity) kontrolü yok.** Yüksek korelasyonlu
öngörücüler, katsayı yorumu üzerine kurulu argüman. → VIF/tolerans raporu isteyin.

**Zaman serisinde durağanlık ve sahte regresyon.** Birim kök testi yok, düzey
serilerle regresyon. → "Serilerin durağanlığı test edilmemiş; düzey serilerle
kurulan regresyon sahte ilişki üretebilir."

## D. Makine öğrenmesine özgü

**Veri sızıntısı.** En sık ve en ağır olanı. İşaretleri: ölçekleme/öznitelik
seçimi/aşırı örnekleme (SMOTE) bölmeden **önce** tüm veri üzerinde yapılmış; aynı
denek veya aynı kaynak hem eğitimde hem testte; hedefle mantıksal olarak aynı
bilgiyi taşıyan öznitelik; zaman serisinde rastgele bölme. → Bildirilen performans
gerçek dışıdır. → "Kritik" etiketiyle yaz, düzeltilmiş kurguyla yeniden
raporlama isteyin.

**Kronolojik olmayan bölme.** Zamana bağlı veride rastgele karıştırma. → Gelecek
bilgi geçmişi tahmin eder, performans şişer. → Kronolojik bölme veya kayan
pencereli doğrulama isteyin.

**Temel model yokluğu.** Yalnızca karmaşık modeller karşılaştırılmış. → Karmaşıklığın
katkısı gösterilemez. → "Basit bir temel model (ör. lojistik regresyon veya
naif tahmin) eklenmeli; önerilen modelin katkısı bu karşılaştırma olmadan
değerlendirilemez."

**Dengesiz veride yalnızca doğruluk.** %95 doğruluk, sınıf dağılımı 95/5. →
Sabit tahmin aynı skoru verir. → "Sınıf dağılımı verildiğinde doğruluk tek başına
bilgi taşımıyor; precision, recall, F1 ve PR-AUC (veya MCC) eklenmeli, karışıklık
matrisi verilmeli."

**Test kümesinde model seçimi.** Hiperparametreler test performansına göre
seçilmiş. → Test kümesi artık bağımsız değildir. → Ayrı doğrulama kümesi veya
iç içe çapraz doğrulama isteyin.

**Tek koşu sonucu.** Rastgelelik içeren modelde tek tohum. → Fark, gürültü
olabilir. → "Sonuçlar en az 5 farklı tohumla tekrarlanıp ortalama ve standart
sapma verilmeli; aksi hâlde modeller arası [x] puanlık fark gürültüden
ayırt edilemez."

**Literatürle adaletsiz karşılaştırma.** Kendi modeli ayarlanmış, karşılaştırılan
yöntemler varsayılan ayarlarla veya başka veri setindeki yayınlanmış sayılarla
karşılaştırılmış. → Aynı veri, aynı bölme, aynı ayar bütçesi isteyin.

**Öznitelik öneminin nedensellik gibi sunulması.** SHAP değeri yüksek diye "X,
Y'nin nedenidir". → Önem ölçüsü modele dairdir, dünyaya dair değil. → Yorumu
model düzeyinde sınırlandırmayı isteyin.

---

## Bulguyu yazma dili

Belirsizse soruya çevir; bu hem dürüst hem etkilidir:

- Kesin: "Ölçekleme bölmeden önce tüm veri üzerinde yapılmış (Kod 2.1)."
- Belirsiz: "Ön işlemenin bölmeden önce mi sonra mı uygulandığı metinden
  anlaşılmıyor. Sızıntı riski nedeniyle bu sıranın açıkça belirtilmesi gerekiyor."

Sayıyı metinden almadıysan yazma. Kendi hesabını yaptıysan hesabı göster:
"Tablo 2'deki alt grup n değerlerinin toplamı 418; yöntemde belirtilen örneklem
442. Fark açıklanmalı." Böyle bir aritmetik kontrol, raporun en ikna edici
kısmıdır — ve yapması en kolay olanıdır.
